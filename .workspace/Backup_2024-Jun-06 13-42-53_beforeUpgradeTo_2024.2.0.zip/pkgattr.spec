<?xml version="1.0" encoding="utf-8"?>
<ATTRIBUTES xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <ATTRIBUTE-DEFINITIONS>
        <DEFINITION xsi:type="anAttributeDef">
            <NAME xsi:type="unicode">Estimated Duration [min]</NAME>
            <REQUIRED xsi:type="boolean">False</REQUIRED>
        </DEFINITION>
        <DEFINITION xsi:type="anAttributeChoiceDef">
            <NAME xsi:type="unicode">Execution Priority</NAME>
            <REQUIRED xsi:type="boolean">False</REQUIRED>
            <VALUE-LIST>
                <VALUE xsi:type="unicode">1</VALUE>
                <VALUE xsi:type="unicode">2</VALUE>
                <VALUE xsi:type="unicode">3</VALUE>
                <VALUE xsi:type="unicode">4</VALUE>
                <VALUE xsi:type="unicode">5</VALUE>
            </VALUE-LIST>
        </DEFINITION>
        <DEFINITION xsi:type="anAttributeChoiceDef">
            <NAME xsi:type="unicode">Status</NAME>
            <REQUIRED xsi:type="boolean">False</REQUIRED>
            <VALUE-LIST>
                <VALUE xsi:type="unicode">Design</VALUE>
                <VALUE xsi:type="unicode">For Review</VALUE>
                <VALUE xsi:type="unicode">Locked</VALUE>
                <VALUE xsi:type="unicode">Ready</VALUE>
            </VALUE-LIST>
        </DEFINITION>
        <DEFINITION xsi:type="anAttributeMultipleChoiceDef">
            <NAME xsi:type="unicode">Testlevel</NAME>
            <REQUIRED xsi:type="boolean">False</REQUIRED>
            <VALUE-LIST>
                <VALUE xsi:type="unicode">component</VALUE>
                <VALUE xsi:type="unicode">module</VALUE>
                <VALUE xsi:type="unicode">not specified</VALUE>
                <VALUE xsi:type="unicode">subsystem</VALUE>
                <VALUE xsi:type="unicode">system</VALUE>
            </VALUE-LIST>
        </DEFINITION>
        <DEFINITION xsi:type="anAttributeDef">
            <NAME xsi:type="unicode">Designer</NAME>
            <REQUIRED xsi:type="boolean">False</REQUIRED>
        </DEFINITION>
        <DEFINITION xsi:type="anAttributeDef">
            <NAME xsi:type="unicode">Design Contact</NAME>
            <REQUIRED xsi:type="boolean">False</REQUIRED>
        </DEFINITION>
        <DEFINITION xsi:type="anAttributeDef">
            <NAME xsi:type="unicode">Design Department</NAME>
            <REQUIRED xsi:type="boolean">False</REQUIRED>
        </DEFINITION>
        <DEFINITION xsi:type="anAttributeDef">
            <NAME xsi:type="unicode">Test Comment</NAME>
            <REQUIRED xsi:type="boolean">False</REQUIRED>
        </DEFINITION>
        <DEFINITION xsi:type="anAttributeDef">
            <NAME xsi:type="unicode">Tools</NAME>
            <REQUIRED xsi:type="boolean">False</REQUIRED>
        </DEFINITION>
        <DEFINITION xsi:type="anAttributeDef">
            <NAME xsi:type="unicode">VersionCounter</NAME>
            <REQUIRED xsi:type="boolean">False</REQUIRED>
        </DEFINITION>
    </ATTRIBUTE-DEFINITIONS>
</ATTRIBUTES>
